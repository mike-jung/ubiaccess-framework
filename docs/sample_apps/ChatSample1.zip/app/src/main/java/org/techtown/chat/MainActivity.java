package org.techtown.chat;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
  private static final String TAG = "MainActivity";

  ChatThread thread;

  EditText hostInput;
  EditText portInput;

  EditText idInput;
  EditText passwordInput;
  EditText receiverInput;
  EditText dataInput;

  String userId;
  String userPassword;

  TextView dataOutput;
  TextView logOutput;


  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    // 서버 연결정보 설정
    hostInput = findViewById(R.id.hostInput);
    portInput = findViewById(R.id.portInput);

    AppInfo.host = hostInput.getText().toString().trim();
    String portStr = portInput.getText().toString().trim();
    try {
      AppInfo.port = Integer.parseInt(portStr);
    } catch(Exception e) {}

    // 입력상자 참조
    idInput = findViewById(R.id.idInput);
    passwordInput = findViewById(R.id.passwordInput);
    receiverInput = findViewById(R.id.receiverInput);
    dataInput = findViewById(R.id.dataInput);

    dataOutput = findViewById(R.id.dataOutput);
    logOutput = findViewById(R.id.logOutput);

    // 스레드 시작
    thread = new ChatThread(this);
    thread.start();


    // 로그인 버튼 클릭 시
    Button loginButton = findViewById(R.id.loginButton);
    loginButton.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        // id, password 입력값
        userId = idInput.getText().toString().trim();
        userPassword = passwordInput.getText().toString().trim();

        // 로그인 요청
        thread.doLogin(userId, userPassword, "hello", "hello");
      }
    });


    // 로그아웃 버튼 클릭 시
    Button logoutButton = findViewById(R.id.logoutButton);
    logoutButton.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        // 로그아웃 요청
        thread.doLogout(userId);
      }
    });


    // 전송 버튼 클릭 시
    Button sendButton = findViewById(R.id.sendButton);
    sendButton.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        String receiverId = receiverInput.getText().toString().trim();
        String data = dataInput.getText().toString().trim();

        // 로그인 요청
        thread.doSend(userId, receiverId, data);
      }
    });

  }

  /**
   * 수신 데이터 출력
   */
  public void showData(String data) {
    runOnUiThread(() -> {
      dataOutput.append(data);
    });
  }

  /**
   * 로그 출력
   */
  public void println(String message) {
    runOnUiThread(() -> {
      logOutput.append(message + "\n");
    });
  }

  /**
   * 토스트 메시지 보이기
   */
  public void showToast(String message) {
    runOnUiThread(() -> {
      Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    });
  }

}
