package org.techtown.chat;

import android.util.Log;

import com.google.gson.Gson;

import org.json.JSONObject;

import java.net.URISyntaxException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.concurrent.atomic.AtomicLong;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;
import okhttp3.OkHttpClient;

/**
 * 채팅을 위한 스레드
 *
 * @author Mike
 *
 */

public class ChatThread extends Thread {
    private static final String TAG = "ChatThread";

    // 웹소켓 객체
    Socket socket;

    // 리스너 등록 여부
    boolean registered = false;

    public static final int CONNECTED = 1;
    public static final int DISCONNECTED = 2;

    // 서버 연결 상태
    int connStatus = DISCONNECTED;

    // AtomicLong object for request id creation
    private static final AtomicLong counter = new AtomicLong(System.currentTimeMillis());

    MessageData messageReceived;

    MainActivity activity;

    // 내 id
    String myId;

    public ChatThread(MainActivity activity) {
        this.activity = activity;
    }

    public void run() {
        try {
            connect(null, AppInfo.secure);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Callback to send data object after socket connected
     */
    public static interface EmitOnConnectionCallback {
        public void onConnected();
    }


    public void connect(EmitOnConnectionCallback callback, boolean isSecure) throws URISyntaxException, NoSuchAlgorithmException, KeyManagementException {
        Log.d(TAG, "connect called.");

        createSocket(isSecure);
        registerListener(callback);
        connectSocket();
    }

    /**
     * 소켓 생성
     */
    public void createSocket(boolean isSecure) throws URISyntaxException, NoSuchAlgorithmException, KeyManagementException {
        if (isSecure) {
            AppInfo.url = "https://" + AppInfo.host + ":" + AppInfo.port;
        } else {
            AppInfo.url = "http://" + AppInfo.host + ":" + AppInfo.port;
        }
        Log.d(TAG, "createSocket called -> url : " + AppInfo.url);

        if (isSecure) {

            // X509TrustManager
            X509TrustManager x509TrustManager = new X509TrustManager() {
                @Override
                public X509Certificate[] getAcceptedIssuers() {
                    X509Certificate[] x509Certificates = new X509Certificate[0];
                    return x509Certificates;
                }

                @Override
                public void checkServerTrusted(final X509Certificate[] chain,
                                               final String authType) throws CertificateException {
                    Log.d(TAG, ": authType: " + String.valueOf(authType));
                }

                @Override
                public void checkClientTrusted(final X509Certificate[] chain,
                                               final String authType) throws CertificateException {
                    Log.d(TAG, ": authType: " + String.valueOf(authType));
                }
            };

            OkHttpClient.Builder okHttpClientBuilder = new OkHttpClient.Builder();
            try {
                SSLContext sslContext = SSLContext.getInstance("TLS");
                sslContext.init(null, trustAllCerts, new SecureRandom());
                SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();
                okHttpClientBuilder.sslSocketFactory(sslSocketFactory, x509TrustManager);
            } catch (Exception e) {
                e.printStackTrace();
            }

            okHttpClientBuilder.hostnameVerifier(new RelaxedHostNameVerifier());
            OkHttpClient okHttpClient = okHttpClientBuilder.build();

            IO.setDefaultOkHttpCallFactory(okHttpClient);
            IO.setDefaultOkHttpWebSocketFactory(okHttpClient);

            IO.Options options = new IO.Options();
            options.forceNew = false;
            options.reconnection = true;
            //options.secure = true;
            options.callFactory = okHttpClient;
            options.webSocketFactory = okHttpClient;

            options.reconnectionDelay = 500;
            options.reconnectionAttempts = 900000000;

            options.transports = new String[] {
                    "websocket"
            };

            socket = IO.socket(AppInfo.url, options);

        } else {
            IO.Options options = new IO.Options();
            options.forceNew = false;
            options.reconnection = true;

            options.reconnectionDelay = 500;
            options.reconnectionAttempts = 900000000;

            options.transports = new String[] {
                    "websocket"
            };

            socket = IO.socket(AppInfo.url, options);
        }
    }

    private TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
        public X509Certificate[] getAcceptedIssuers() {
            return new X509Certificate[]{};
        }

        public void checkClientTrusted(X509Certificate[] chain,
                                       String authType) throws CertificateException {
        }

        public void checkServerTrusted(X509Certificate[] chain,
                                       String authType) throws CertificateException {
        }
    }};

    public class RelaxedHostNameVerifier implements HostnameVerifier {
        public boolean verify(String hostname, SSLSession session) {
            return true;
        }
    }

    /**
     * 리스너 등록
     */
    public void registerListener(final EmitOnConnectionCallback callback) {
        socket.on("connect", new Emitter.Listener() {
            @Override
            public void call(Object... args) {
                Log.d(TAG, "웹소켓 서버에 연결되었습니다. : " + AppInfo.url);

                if (connStatus == DISCONNECTED) {
                    connStatus = CONNECTED;
                }

                if (!registered) {
                    register("connect");
                    register("disconnect");
                    register("response");
                    register("message");

                    registered = true;
                }

                if (callback != null) {
                    callback.onConnected();
                }

            }
        });
    }

    /**
     * 소켓 연결
     */
    public void connectSocket() {
        socket.connect();
    }

    /**
     * Create a new request id
     */
    public long createRequestCodeLong() {
        return counter.getAndIncrement();
    }

    public String createRequestCode() {
        return String.valueOf(createRequestCodeLong());
    }

    /**
     * 로그인 요청
     */
    public void doLogin(String id, String password, String alias, String today) {
        try {
            String requestCode = createRequestCode();

            JSONObject output = new JSONObject();
            output.put("requestCode", requestCode);
            output.put("userId", id);
            output.put("id", id);
            output.put("password", password);
            output.put("alias", alias);
            output.put("today", today);

            activity.println("서버로 보낼 데이터 : " + output.toString());

            if (connStatus == DISCONNECTED) {
                Log.d(TAG, "서버에 연결되어 있지 않습니다. 먼저 서버에 연결하세요.");
                return;
            }

            send("login", output);

            this.myId = id;

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 로그아웃 요청
     */
    public void doLogout(String id) {
        try {
            if (connStatus == CONNECTED) {
                logout(id);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 서버에 로그아웃 전송하고 로그아웃 기능 처리
     */
    public void logout(String id) {
        try {
            String requestCode = createRequestCode();

            JSONObject output = new JSONObject();
            output.put("requestCode", requestCode);
            output.put("userId", id);
            output.put("id", id);

            activity.println("서버로 보낼 데이터 : " + output.toString());

            if (connStatus == DISCONNECTED) {
                Log.d(TAG, "서버에 연결되어 있지 않습니다. 먼저 서버에 연결하세요.");
                return;
            }

            send("logout", output);

            if (socket != null) {
                // 리스너 해제
                socket.off("connect");
                socket.off("disconnect");
                socket.off("response");
                socket.off("message");

                socket.disconnect();
                socket = null;

                connStatus = DISCONNECTED;

                Log.d(TAG, "웹소켓 연결을 종료했습니다.");

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 전송 요청
     */
    public void doSend(String senderId, String receiverId, String data) {
        try {
            String requestCode = createRequestCode();

            JSONObject output = new JSONObject();
            output.put("requestCode", requestCode);
            output.put("userId", senderId);
            output.put("sender", senderId);
            output.put("receiver", receiverId);
            output.put("command", "chat");
            output.put("type", "text");
            output.put("data", data);

            activity.println("서버로 보낼 데이터 : " + output.toString());

            if (connStatus == DISCONNECTED) {
                Log.d(TAG, "서버에 연결되어 있지 않습니다. 먼저 서버에 연결하세요.");
                return;
            }

            send("message", output);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 수신한 이벤트 처리하는 리스너 등록
     */
    public void register(String event) {
        Log.d(TAG, "이벤트 등록 호출됨 : " + event);

        try {
            if (event.equals("disconnect")) {
                socket.on(event, new Emitter.Listener() {
                    @Override
                    public void call(Object... args) {
                        connStatus = DISCONNECTED;

                        activity.println("웹소켓 연결이 종료되었습니다.");
                    }
                });

            } else if (event.equals("connect")) {
                socket.on(event, new Emitter.Listener() {
                    @Override
                    public void call(Object... args) {
                        connStatus = CONNECTED;

                        activity.println("웹소켓이 연결되었습니다.");
                    }
                });

            } else if (event.equals("response")) {
                socket.on(event, new Emitter.Listener() {
                    @Override
                    public void call(Object... args) {
                        activity.println("응답 메시지 : " + args[0]);

                    }

                });

            } else if (event.equals("message")) {
                socket.on(event, new Emitter.Listener() {
                    @Override
                    public void call(Object... args) {
                        activity.println("수신 메시지 : " + args[0]);

                        parseData(args[0].toString());

                    }
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void parseData(String data) {
        Gson gson = new Gson();
        MessageData message = gson.fromJson(data, MessageData.class);

        activity.showData(message.data);

    }


    public void send(final String event, final JSONObject data) throws URISyntaxException, NoSuchAlgorithmException, KeyManagementException {
        if (connStatus == DISCONNECTED) {
            Log.d(TAG, "socket is disconnected");
            socket.disconnect();
            socket = null;

            connect(new EmitOnConnectionCallback() {
                @Override
                public void onConnected() {
                    socket.emit(event, data);
                }
            }, AppInfo.secure);

        } else {
            Log.d(TAG, "socket is connected");
            socket.emit(event, data);
        }
    }

}

