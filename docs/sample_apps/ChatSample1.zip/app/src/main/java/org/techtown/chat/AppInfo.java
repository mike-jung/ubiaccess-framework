package org.techtown.chat;

public class AppInfo {

    public static String url;
    public static String host;
    public static int port;
    public static boolean secure = false;

}
